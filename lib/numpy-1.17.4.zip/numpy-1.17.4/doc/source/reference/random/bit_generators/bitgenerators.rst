:orphan:

BitGenerator
------------

.. currentmodule:: numpy.random.bit_generator

.. autosummary::
   :toctree: generated/

    BitGenerator
